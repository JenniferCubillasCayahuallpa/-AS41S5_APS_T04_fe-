import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive], // <-- navegación
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss' 
})
export class SidebarComponent {
}