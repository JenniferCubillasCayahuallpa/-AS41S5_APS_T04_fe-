import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet], // Quitamos SidebarComponent de aquí
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class AppComponent { } // Asegúrate de que se llame AppComponent